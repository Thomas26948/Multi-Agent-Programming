## Question 1

L'environnement est inaccessible car les Ship n'ont pas accès à toutes les informations échangées dans la simulation. Il ne connaissent ni la position des autres Ships ni celle des différents items en attente. Leur prise de décision est basé uniquement sur ce que les planètes communiquent aux Ships. 

Le nombre d'états du système est infini comme il existe une infinité d'Item différents. Comme leur apparition est aussi aléatoire cela rajoute un autre niveau dans le nombre d'états différent de la simulation.


Les Ships renvoient toujours le même template de réponse aux call for proposal et les PlanetManager appliquent toujours la même stratégie (choisir la plus grande utility) on est donc dans le cadre déterministe.

Les Ships n'ont pas à faire de retour à leur point de départ après une livraison et l'apparition de nouveau Items modifient l'environnement. Il est est donc très peu problable de revenir à l'état de départ, il est donc non épisodique.

Finalement, les changements ne dépendent que des agents le traitement des Items se fait par les Ships uniquement et les planètes sont immobiles. On a donc un evironnement statique. 


## Question 2

Les Items sont de simples objets ils n'ont pas d'effet sur l'environnement ou d'action à réaliser ce ne sont donc pas des agents.

## Question 3

Comme on peut s'y attendre, plus il y a de planètes, plus il y a d'Item. Ainsi, comme on peut le voir sur l'image suivantes, s'il y a peu de planètes taux d'Item livrés est en général proche des 100%. Car il y a assez de Ships pour transporter tout les Items. 

*5 planètes et 15 Ships*


![](./LP.png)

Au contraire, lorsqu'il y a beaucoup de planètes la demande pour les livraisons ne peuvent pas être assurées assez rapidement et l'écart entre le nombre d'Items et le nombre de livraison ne fait que grandir. 

*20 planètes et 15 Ships*

![](./HP.png)

De même on en déduit que le nombre de Ships à l'effet inverse. Plus il y a de Ships plus des délais de livraisons sont court et moins les Items on le temps de s'accumuler.





## Question 4

La simulation est un modèle de coopération, les Ships n'ont pas de score personnel à améliorer en faisant des livraisons de plus par rapport aux autres. Le seul objectif est que la livraison soit effectuée quelque soit le Ship.

## Question 5

Ce changement sur le réseau de planètes n'a un effet que sur la taxonomie du réseau. On passe d'une simulation statique à une simulation dynamique car le changement vitesse sur les arêtes ne dépend pas des agents. Les autres charactéristiques restent inchangées par rapport à la question 1. 


## Question 6

La vitesse de déplacement des Ship correspond à l'état de la route qu'ils empruntent. Les actions des Ships sont donc influencées par l'environnement ce qui correspond à la charactéristique de l'adaptabilité

## Question 7

Comme l'état des routes n'est jamais srictement meilleur que dans le cas précédent, le système est en moyenne dans un état pire que précedement (temps de trajet entre deux planètes plus grand). Les livraisons sont donc retardées et comme dans le cas avec peu de Ships le retard s'accumule petit à petit.

*cas classique 10 planètes 15 Ships*

![](./usual_roads.png)

*cas déterioré 10 planètes 15 Ships*

![](./bad_roads.png)


## Question 8


Plus le branching factor est élevé plus le graphe est dense on a donc tendance à réduire la distance entre les planètes et donc le temps de livraison. Ainsi, le nombre de livraison varie dans la même direction que le slider branching factor.